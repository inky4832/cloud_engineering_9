package exam03_데이터형변환및표준출력;

public class ConsoleTest {

	public static void main(String[] args) {

		// 콘솔에 출력 (표준 출력)
		// 1. System.out.println(값)==> 개행출력
		System.out.println("Hello");
		System.out.println("World");
		System.out.println();
		
		//2.System.out.print(값) ==> 개행없이 출력
		System.out.print("Hello");
		System.out.print("World");
		System.out.println();
		
		//3. System.out.printf("형식문자", 값,...) ==> 개행없이출력 + 포맷지정
		// PrintStream java.io.PrintStream.printf(String format, Object ... args)
		System.out.printf("이름:%s 나이:%d 키:%.2f 결혼여부:%b 성별:%c", "홍길동", 20, 185.2563, true, '남').println();
		System.out.printf("이름:%s 나이:%d 키:%.2f 결혼여부:%b 성별:%c", "홍길동", 20, 185.2563, true, '남');
		
	}

}
