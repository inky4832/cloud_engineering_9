package exam16_인터페이스;

public class MyClass {

}
