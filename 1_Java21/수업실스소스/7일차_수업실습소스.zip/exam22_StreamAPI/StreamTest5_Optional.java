package exam22_StreamAPI;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamTest5_Optional {

	public static void main(String[] args) {
		

		//Optional 실습
		List<Integer> list = new  ArrayList<Integer>();
		 //데이터가 존재하지 않는 경우
//		list.add(30);
//		list.add(30);

		// Optional에서 지원하는 메서드 사용안한 경우
		OptionalDouble x =list.stream().mapToDouble(n->n).average();
		//System.out.println(x.getAsDouble()); // 오류 발생

        System.out.println("================================================");

		// Optional에서 지원하는 메서드 사용한 경우
		double avg  = list.stream().mapToDouble(n->n).average().orElse(0.0);
		System.out.println(avg);
		
	}
}



