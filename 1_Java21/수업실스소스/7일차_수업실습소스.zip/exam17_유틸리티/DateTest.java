package exam17_유틸리티;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTest {

	public static void main(String[] args) throws Exception{
		
		 Date d = new Date();
		 System.out.println(d);  // Wed Apr 08 16:39:41 KST 2026

		//2. SimpleDateFormat 클래스 이용한 Date클래스 포맷 출력
		SimpleDateFormat sdf = new  SimpleDateFormat("yyyy");
		String result = sdf.format(new Date());
		System.out.println("2. Date 클래스에서 년도만 반환: "+ result);

		SimpleDateFormat sdf2 = new  SimpleDateFormat("yyyy/MM/dd");
		String result2 = sdf2.format(new Date());
		System.out.println("3. Date 클래스에서 년/월/일  반환: "+ result2);

		SimpleDateFormat sdf3 = new  SimpleDateFormat("yyyy년 MM월 dd일  HH:mm:ss a");
		String result3 = sdf3.format(new Date());
		System.out.println("4. Date 클래스에서 날자포맷 지정후  반환: "+ result3);


		//3. 문자열로 된 날짜포맷 ----> Date 클래스 타입으로 변환
		SimpleDateFormat sdf4 = new  SimpleDateFormat("yyyy/MM/dd");

		String s = "2020/11/12";
		Date dd = sdf4.parse(s);
		System.out.println("5. 문자열-->날짜로 변환: " + dd);

	}
}
