package exam17_유틸리티;

import java.util.Random;

public class RandomTest {
    public static void main(String[] args) {
        Random rand = new Random();

        int result = rand.nextInt();
        System.out.println("1. 임의의 정수값: " + result);

        int result2 = rand.nextInt(3);
        System.out.println("2. 0~2 사이의 정수값: " + result2);

        boolean result3 = rand.nextBoolean();
        System.out.println("3. 임의의 논리값: " + result3);

        float result4 = rand.nextFloat();
        System.out.println("4. 임의의 float값: " + result4);

        double result5 = rand.nextDouble();
        System.out.println("5. 임의의 double값: " + result5);

    }
}
