package exam20_컬렉션API;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

class Person {

	String name;
	int age;

	public Person() {
	}

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}

}



public class ArrayListTest2 {

	public static void main(String[] args) {

//		ArrayList<Person> list = new ArrayList<Person>();
		List<Person> list = new ArrayList<Person>();

		list.add(new Person("홍길동1", 20));
		list.add(new Person("홍길동2", 30));
		list.add(new Person("홍길동3", 40));

		for (Person p : list) {
			System.out.println(p);
		}

	}

}
