package exam14_접근지정자3_은닉화;

public class Person {

	private String name;
	private int age;
	
	public Person() {
	}

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	//검증처리 
	private boolean ageCheck(int age) {
		boolean result = false;
		if(age<100) {
			result = true;
		}
		return result;
	}
	
	public void setAge(int age) {
		if(ageCheck(age)) {
			this.age = age;
		}else {
			System.out.println("age값 유효하지 않음");
		}
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
	
	
}
