package exam14_접근지정자3_은닉화;

public class TestPerson {

	public static void main(String[] args) {

		Person p = new Person();
	
		// 은닉화 개념1
		//- 변수는 private 지정해서 외부에서 직접 접근 불가(잘못된 데이터 설정 방지)
		//   + 검증작업을 처리할 수 있는 setter 메서드 사용하여 값을 저장.
//		p.age = 2000;	
		p.setName("홍길동");
		p.setAge(20);
		
		// 은닉화 개념2
        // - 외부에서 접근시 복잡하지 하도록 처리				
		System.out.println(p);  // p.toString() 동일
	
		
	}

}
