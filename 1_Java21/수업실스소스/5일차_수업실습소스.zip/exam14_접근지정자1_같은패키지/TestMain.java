package exam14_접근지정자1_같은패키지;

public class TestMain {

	public static void main(String[] args) {

		Sub s = new Sub();
		s.info();
		
	}

}
