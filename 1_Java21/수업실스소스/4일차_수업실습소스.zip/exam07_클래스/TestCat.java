package exam07_클래스;


// Cat 클래스를 관리하는 용도( 객체생성,값설정, 값조회,...)
// '핸들링 클래스' 라고 부른다.
// Cat 클래스를 사용하기 위한 방법은 객체생성(인스턴스화)이다.
// 문법:   클래스명  변수명 = new 클래스명();

public class TestCat {

	public static void main(String[] args) {
		
		//Cat 클래스 객체생성
		Cat c = new Cat();
		
		/*
		 *  c 변수: 로컬변수(local 변수), stack 메모리 저장, 사용전에 초기화 필수
		 *         메서드 호출할 때 생성~메서드 끝날 때 제거.
		 *         호출할 때마다 매번 생성(임시변수)
		 *       : 참조형 변수 (주소값 저장)
		 * 
		 */
		
		// 값 저장
		c.name = "야옹이";
		c.age = 2;
		c.sex = "암놈";
		
		System.out.println(c.name+"\t"+c.age+"\t"+c.sex);
		
		Cat c2 = new Cat();
		c2.name="나비";
		c2.age=1;
		c2.sex="숫놈";
		System.out.println(c2.name+"\t"+c2.age+"\t"+c2.sex);
		

	}

}
