package exam09_this;


public class Student {

	String name;
	int age;
	String address;
	
	public Student() {
	}
	public Student(String name) {
		this(name,0); // 반드시 첫라인에 사용해야 된다.
		System.out.println();
	}
	public Student(String name, int age) {
		this(name,age,"서울");
	}
	public Student(String name, int age, String address) {
		this.name = name;
		this.age = age;
		this.address = address;
	}
	
	
}
