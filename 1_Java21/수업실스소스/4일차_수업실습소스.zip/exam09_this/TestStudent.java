package exam09_this;


public class TestStudent {

	public static void main(String[] args) {

		// 서울에 사는 4명의 학생
		Student s2 = new Student("홍길동");
		Student s3 = new Student("이순신",20);
		Student s4 = new Student("유관순",30);
		Student s5 = new Student("강감찬",40);
		
	}

}
