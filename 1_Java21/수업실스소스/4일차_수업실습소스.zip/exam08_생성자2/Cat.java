package exam08_생성자2;


public class Cat {

	String name;
	int age;
	String sex;
	
	// 기본생성자가 자동으로 생성됨.
	// ==>public Cat(){}
	
	public Cat() {}
	
	// 명시적으로 생성자 지정한 경우==> 기본생성자를 제공안함
	public Cat(String n,int a, String s) {
		name = n;
		age = a;
		sex = s;
	}
}
