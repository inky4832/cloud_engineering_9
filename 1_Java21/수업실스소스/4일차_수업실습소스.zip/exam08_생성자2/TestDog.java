package exam08_생성자2;


public class TestDog {

	public static void main(String[] args) {

		//1. 이름과 나이,성별을 모르는 경우.
		Dog d = new Dog();
		d.name="강아지1";
		d.age=2;
		d.sex="암놈";
		
		//2. 이름만 아는 경우
		Dog d2 = new Dog("강아지2");
		d2.age=1;
		d2.sex="숫놈";
		
		//3. 이름과 나이만 아는 경우
		Dog d3 = new Dog("강아지3", 4);
		
		//4. 이름,나이,성별 모두 아는 경우
		Dog d4 = new Dog("강아지4", 2, "숫놈");
		
		
	}

}
