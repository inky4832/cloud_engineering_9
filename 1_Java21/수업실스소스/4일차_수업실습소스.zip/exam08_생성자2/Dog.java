package exam08_생성자2;


public class Dog {

	// 인스턴스 변수, heap 메모리
	String name;
	int age;
	String sex;
	
	//오버로딩 생성자
	public Dog() {
		System.out.println("Dog 기본 생성자");
	}

	public Dog(String name, int age, String sex) { //로컬변수, stack메모리
		this.name = name;
		this.age = age;
		this.sex = sex;
	}

	public Dog(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public Dog(String name) {
		this.name = name;
	}
	
	
	
}
