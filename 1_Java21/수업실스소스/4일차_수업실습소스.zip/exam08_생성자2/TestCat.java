package exam08_생성자2;


public class TestCat {

	public static void main(String[] args) {

		Cat c = new Cat("야옹",2,"암놈");
		Cat c2 = new Cat();
		c2.name="나비";
		c2.age=2;
		c2.sex="숫놈";
	}

}
