package exam10_메서드;


public class Dog {

	//1. 인스턴스 변수
	private String name;
	private int age;
	private String sex;
	
	//2. 생성자
	public Dog() {
		System.out.println("Dog 생성자");
	}

	public Dog(String name, int age, String sex) {
		this.name = name;
		this.age = age;
		this.sex = sex;
	}
	//3. 메서드(getter/setter)

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if(age<=15) {
		 this.age = age;
		}else {
			System.out.println("age 값 잘못 입력...");
		}
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}
	
	// 추가적인 기능을 가진 메서드 제공 가능하다.
}
