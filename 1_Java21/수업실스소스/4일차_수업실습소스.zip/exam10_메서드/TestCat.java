package exam10_메서드;


public class TestCat {

	public static void main(String[] args) {

		Cat c = new Cat("야옹이", 2, "암놈");
		
		//c.age=30000;  //논리적으로 문제 발생 ==> 메서드 이용
		c.setAge(3000);
		c.setName("나미");
		c.setSex("숫놈");
		
		int age = c.getAge();
		String name = c.getName();
		String sex = c.getSex();
		
		System.out.println(age+"\t"+name+"\t"+sex);
		
		
	}

}
