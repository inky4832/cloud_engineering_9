package exam10_메서드;


public class Cat {

	//1. 인스턴스 변수
	private String name;
	private int age;
	private String sex;
	
	//2. 생성자
	
	public Cat() {
		System.out.println("Cat 생성자");
	}

	public Cat(String name, int age, String sex) {
		this.name = name;
		this.age = age;
		this.sex = sex;
	}
	//3. 메서드 ==> 인스턴스변수값을 변경(설정) ==> setter메서드
	public void setAge(int a) {
		if(a<=15) {
		  age = a;
		}else {
			System.out.println("고양이 age값이 잘못됨. 확인하시오.");
		}
	}
	public void setName(String n) {
		name = n;
	}
	public void setSex(String s) {
		sex = s;
	}
	
	//4. 메서드 ==> 인스턴스변수값을 반환 ==> getter 메서드
	public int getAge() {
		return age;
	}
	public String getName() {
		return name;
	}
	public String getSex() {
		return sex;
	}
	
	//추가로 다양한 기능을 하는 메서드 지정가능하다.
}












