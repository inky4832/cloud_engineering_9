package exam10_메서드;


public class TestDog {

	public static void main(String[] args) {

		Dog d = new Dog("장군", 2, "숫놈");
		
		System.out.println("현재 Dog 정보");
		System.out.println(d.getName()+"\t"+d.getAge()+"\t"+d.getSex());
		
		System.out.println("내년 Dog 정보");
		d.setAge(d.getAge()+1);
		System.out.println(d.getName()+"\t"+d.getAge()+"\t"+d.getSex());
		
	}

}
