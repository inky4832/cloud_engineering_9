package exam08_생성자;


public class Cat {

	String name;
	int age;
	String sex;
	
	//생성자 ==> 반드시 호출해야 실행된다.
	//오버로딩 생성자: 동일한 이름의 생성자가 여러개 지정가능하다. 단, 인자리스트가 달라야 된다.(갯수,순서,타입)
	public Cat() {
		//초기화
		System.out.println("생성자호출");
	}
	public Cat(String s, int n, int a) {}
	public Cat(String n, int a, String s) { //로컬변수, 파라미터변수
		name = n;
		//a 값의 유효성 검사 가능
		if(a<15) {
			age = a;
		}
		sex = s;
	}
	
	
	
	
	
	
	
}
