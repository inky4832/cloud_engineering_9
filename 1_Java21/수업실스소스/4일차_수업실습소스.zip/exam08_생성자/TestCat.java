package exam08_생성자;


public class TestCat {

	public static void main(String[] args) {

		System.out.println("start");
		//1. 객체생성후 c.멤버변수 형식으로  인스턴스변수에 초기화, 직접 인스턴스변수 접근방법은 권장하지 않는다.(논리적으로 문제발생가능)
		Cat c = new Cat();
		c.name="야옹이";
		c.age=2;
		c.sex="암놈";
		System.out.println(c.name+"\t"+c.age+"\t"+c.sex);
		
		//2. 객체생성할 때 인스턴스변수에 초기화, 생성자에서 인자값의 유효성 검사 가능
		Cat c2 = new Cat("나비",10,"숫놈"); // 인자값(arguments)
		System.out.println(c2.name+"\t"+c2.age+"\t"+c2.sex);
		System.out.println("end");
		
		
	}

}
