package exam10_메서드3_callbyValueReference;

class Cat{
	
	String name;
	int age;
	
	public Cat(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	public String getCat() {
		return name+"\t"+age;
	}
}

public class TestMain {

	//1. 기본형 데이터를 전달받는 메서드
	public static void pdt(int num) {
		num = 20;
	}
	
	//2. 참조형 데이터(Cat 클래스)를 전달받는 메서드
	public static void rdt(Cat c) {
		c.age = 3;
	}
	
	public static void main(String[] args) {

		//가. pdt 메서드 데이터 전달
		int n = 10;
		System.out.println("메서드 호출전    기본형 데이터 값:"+ n);
		pdt(n);  // call by value ( 실제값 전달, 따라서 전달받은 메서드에서 값을 변경해도 원본은 영향을 받지 않는다.  )
		System.out.println("메서드 호출후    기본형 데이터 값:"+ n);

		System.out.println();
		
		//나. rdt 메서드에 데이터 전달
		Cat c = new Cat("야옹이",2);
		System.out.println("메서드 호출전    참조형 데이터 값:"+ c.getCat());
		rdt(c);  // call by value reference ( 주소값 전달, 따라서 전달받은 메서드에서 값을 변경하면 원본이 영향을 받는다. )
		System.out.println("메서드 호출후    참조형 데이터 값:"+ c.getCat());
		
	}

}








