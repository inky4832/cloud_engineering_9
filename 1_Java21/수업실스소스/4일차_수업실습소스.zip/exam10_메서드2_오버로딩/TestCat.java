package exam10_메서드2_오버로딩;


public class TestCat {

	public static void main(String[] args) {

		
		//오버로딩 생성자 활용한 객체생성
		Cat c = new Cat();
		Cat c2 = new Cat("야옹", 2, "암컷");
		
		//오버로딩 메서드 활용한 데이터 변경
		c.setCat("나비", 2);
		c2.setCat(3, "수컷");
		
		System.out.println(c.getName()+"\t"+c.getAge()+"\t"+c.getSex());
		System.out.println(c2.getName()+"\t"+c2.getAge()+"\t"+c2.getSex());
		
	}

}
