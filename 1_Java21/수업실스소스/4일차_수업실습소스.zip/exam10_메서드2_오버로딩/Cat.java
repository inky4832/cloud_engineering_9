package exam10_메서드2_오버로딩;


public class Cat {

	private String name;
	private int age;
	private String sex;
	
	// 오버로딩 생성자
	public Cat() {
		System.out.println("Cat 기본생성자");
	}

	public Cat(String name, int age, String sex) {
		this.name = name;
		this.age = age;
		this.sex = sex;
	}
	
	// 오버로딩 메서드
	//1. name과 age 변경하는 메서드
	public void setCat(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	//2. age과 sex 변경하는 메서드
	public void setCat(int age, String sex) {
		this.age = age;
		this.sex= sex;
	}
	// getter
	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getSex() {
		return sex;
	}
	
	
	
	
}










