package exam2.delete;

public class DuplicatedDeptnoException extends Exception {

	public DuplicatedDeptnoException(String message) {
		super(message);
	}
}
