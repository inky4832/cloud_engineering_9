package exam1;

import java.sql.*;

public class SelectTest3 {

	public static void main(String[] args) {

		// Dept 테이블 조회
		//1. 4가지 정보 
	     String driver = "com.mysql.cj.jdbc.Driver"; // 핵심이 되는 클래스명
	     String url = "jdbc:mysql://localhost:3306/testdb";
	     String userid ="root";
	     String passwd = "1234";
		
		//2. 드라이버 로딩
	     try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			 //e.printStackTrace();
			 System.out.println(e.getMessage());
		}
	     
	    //3. Connection 맺기
	     Connection con = null;
	     PreparedStatement pstmt = null;
	     ResultSet rs = null;
	     try {
			 con = DriverManager.getConnection(url, userid, passwd);
			 String sql = "select deptno as no, dname, loc from dept where deptno = ?";
			 pstmt = con.prepareStatement(sql);

			 // ? 대신에 나중에 값을 설정
			 // pstmt.setXXX(?위치,  값);  ex.   setInt, setString
			 pstmt.setInt(1, 10);

			 rs = pstmt.executeQuery();
				while(rs.next()) { // 행선택
					//열선택
					int deptno = rs.getInt("no");   // 컬럼헤더값
					String dname = rs.getString(2); // rs.getString("dname");
					String loc = rs.getString(3);  // rs.getString("loc")
					System.out.printf("%d, %s , %s \n", deptno, dname,loc);
				}
		} catch (SQLException e) {
			 //e.printStackTrace();
			 System.out.println(e.getMessage());
		}finally {
			try {
				 if(rs!=null) rs.close();
				 if(pstmt !=null) pstmt.close();
				 if(con !=null) con.close();
			} catch (SQLException e) {
				//e.printStackTrace();
				System.out.println(e.getMessage());
			}
		}// try~catch~finally
	}//end main
}//end class




