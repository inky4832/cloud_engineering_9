// SwaggerConfig.java
package com.exam.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

  @Bean
  public OpenAPI customOpenAPI() {
    return new OpenAPI()
        .addServersItem(new Server().url("http://localhost:8080").description("Local"))
        .info(new Info()
            .title("Demo User API")
            .description("Spring Boot + Springdoc OpenAPI 샘플")
            .version("v1.0.0")
            .contact(new Contact().name("API Owner").email("owner@example.com")));
  }
}