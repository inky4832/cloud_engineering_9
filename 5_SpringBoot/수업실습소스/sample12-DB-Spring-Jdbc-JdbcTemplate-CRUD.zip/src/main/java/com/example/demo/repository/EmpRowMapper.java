//EmpRowMapper.java
package com.example.demo.repository;

import com.example.demo.dto.EmpDTO;
import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmpRowMapper implements RowMapper<EmpDTO> {
    @Override
    public EmpDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        EmpDTO e = new EmpDTO();
        e.setEmpno(rs.getInt("EMPNO"));
        e.setEname(rs.getString("ENAME"));
        e.setJob(rs.getString("JOB"));

        int mgr = rs.getInt("MGR");
        e.setMgr(rs.wasNull() ? null : mgr);

        var hire = rs.getDate("HIREDATE");
        e.setHiredate(hire != null ? hire.toLocalDate() : null);

        double sal = rs.getDouble("SAL");
        e.setSal(rs.wasNull() ? null : sal);

        int comm = rs.getInt("COMM");
        e.setComm(rs.wasNull() ? null : comm);

        int deptno = rs.getInt("DEPTNO");
        e.setDeptno(rs.wasNull() ? null : deptno);

        return e;
    }
}