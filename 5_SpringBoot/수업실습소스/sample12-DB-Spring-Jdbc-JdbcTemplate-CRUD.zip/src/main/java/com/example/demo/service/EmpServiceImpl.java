// EmpServiceImpl.java
package com.example.demo.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dto.EmpDTO;
import com.example.demo.repository.EmpRepository;
import java.util.List;
import java.util.Optional;

@Service
public class EmpServiceImpl implements EmpService {

    private final EmpRepository repo;

    public EmpServiceImpl(EmpRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<EmpDTO> list() {
        return repo.findAll();
    }

    @Override
    public Optional<EmpDTO> get(Integer empno) {
        return repo.findById(empno);
    }

    @Override
        @Transactional
    public void save(EmpDTO emp) {
        // 존재 여부로 insert/update 분기
        boolean exists = repo.findById(emp.getEmpno()).isPresent();
        if (exists) {
            repo.update(emp);
        } else {
            repo.insert(emp);
        }
    }

    @Override
        @Transactional
    public void delete(Integer empno) {
        repo.delete(empno);
    }
}