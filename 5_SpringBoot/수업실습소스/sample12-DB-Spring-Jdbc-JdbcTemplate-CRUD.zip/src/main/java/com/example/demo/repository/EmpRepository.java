// EmpRepository.java
package com.example.demo.repository;

import java.sql.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.example.demo.dto.EmpDTO;

@Repository
public class EmpRepository {

    private final JdbcTemplate jdbcTemplate;
    private final EmpRowMapper rowMapper = new EmpRowMapper();

    public EmpRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<EmpDTO> findAll() {
        String sql = "SELECT EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO FROM EMP ORDER BY EMPNO";
        return jdbcTemplate.query(sql, rowMapper);
    }

    public Optional<EmpDTO> findById(Integer empno) {
        String sql = "SELECT EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO FROM EMP WHERE EMPNO = ?";
        var list = jdbcTemplate.query(sql, rowMapper, empno);
        return list.isEmpty() ? Optional.empty() : Optional.of(list.get(0));
    }

    public int insert(EmpDTO e) {
        String sql = """
                INSERT INTO EMP (EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;
        return jdbcTemplate.update(sql,
                e.getEmpno(),
                e.getEname(),
                e.getJob(),
                e.getMgr(),
                e.getHiredate() != null ? Date.valueOf(e.getHiredate()) : null,
                e.getSal(),
                e.getComm(),
                e.getDeptno());
    }

    public int update(EmpDTO e) {
        String sql = """
                UPDATE EMP
                   SET ENAME = ?,  HIREDATE = ?, SAL = ?
                 WHERE EMPNO = ?
                """;
        return jdbcTemplate.update(sql,
                e.getEname(),
                e.getHiredate() != null ? Date.valueOf(e.getHiredate()) : null,
                e.getSal(),
                e.getEmpno());
    }

    public int delete(Integer empno) {
        String sql = "DELETE FROM EMP WHERE EMPNO = ?";
        return jdbcTemplate.update(sql, empno);
    }
}