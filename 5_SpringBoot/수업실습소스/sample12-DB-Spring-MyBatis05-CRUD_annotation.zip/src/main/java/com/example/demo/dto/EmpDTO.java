// EmpDTO.java
package com.example.demo.dto;

import java.time.LocalDate;

public class EmpDTO {
    private Integer empno;
    private String ename;
    private String job;
    private Integer mgr;
    private LocalDate hiredate;
    private Double sal;   // schema FLOAT → Double로 매핑
    private Integer comm;
    private Integer deptno;

    public EmpDTO() {}

    // 편의 생성자 (필요시 사용)
    public EmpDTO(Integer empno, String ename, String job, Integer mgr,
               LocalDate hiredate, Double sal, Integer comm, Integer deptno) {
        this.empno = empno;
        this.ename = ename;
        this.job = job;
        this.mgr = mgr;
        this.hiredate = hiredate;
        this.sal = sal;
        this.comm = comm;
        this.deptno = deptno;
    }

    // getters/setters
    public Integer getEmpno() { return empno; }
    public void setEmpno(Integer empno) { this.empno = empno; }
    public String getEname() { return ename; }
    public void setEname(String ename) { this.ename = ename; }
    public String getJob() { return job; }
    public void setJob(String job) { this.job = job; }
    public Integer getMgr() { return mgr; }
    public void setMgr(Integer mgr) { this.mgr = mgr; }
    public LocalDate getHiredate() { return hiredate; }
    public void setHiredate(LocalDate hiredate) { this.hiredate = hiredate; }
    public Double getSal() { return sal; }
    public void setSal(Double sal) { this.sal = sal; }
    public Integer getComm() { return comm; }
    public void setComm(Integer comm) { this.comm = comm; }
    public Integer getDeptno() { return deptno; }
    public void setDeptno(Integer deptno) { this.deptno = deptno; }
}