// EmpServiceImpl.java
package com.example.demo.service;

import com.example.demo.dto.EmpDTO;
import com.example.demo.mappers.EmpMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class EmpServiceImpl implements EmpService {

    private final EmpMapper mapper;

    public EmpServiceImpl(EmpMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public List<EmpDTO> list() {
        return mapper.findAll();
    }

    @Override
    public Optional<EmpDTO> get(Integer empno) {
        return mapper.findById(empno);
    }

    @Override
    @Transactional
    public void save(EmpDTO emp) {
        boolean exists = mapper.findById(emp.getEmpno()).isPresent();
        if (exists) {
            mapper.update(emp);
        } else {
            mapper.insert(emp);
        }
    }

    @Override
    @Transactional
    public void delete(Integer empno) {
        mapper.delete(empno);
    }
}