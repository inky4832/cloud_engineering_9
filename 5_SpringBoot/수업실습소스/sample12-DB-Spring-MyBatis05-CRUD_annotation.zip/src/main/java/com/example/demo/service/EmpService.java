// EmpService.java
package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.dto.EmpDTO;

public interface EmpService {
    List<EmpDTO> list();
    Optional<EmpDTO> get(Integer empno);
    void save(EmpDTO emp);     // 신규/수정 통합
    void delete(Integer empno);
}
