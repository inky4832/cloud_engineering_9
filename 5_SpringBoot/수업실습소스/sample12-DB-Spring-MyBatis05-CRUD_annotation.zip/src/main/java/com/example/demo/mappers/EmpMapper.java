// EmpMapper.java
package com.example.demo.mappers;

import com.example.demo.dto.EmpDTO;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Optional;

@Mapper
public interface EmpMapper {

    @Select("select empno, ename, job, mgr, hiredate, sal, comm, deptno from emp order by empno")
    List<EmpDTO> findAll();

    @Select("select empno, ename, job, mgr, hiredate, sal, comm, deptno from emp where = empno = #{empno}")
    Optional<EmpDTO> findById(@Param("empno") Integer empno);


    @Insert("insert into emp (job, mgr, hiredate, sal, comm, deptno) values ( #{job}, #{mgr}, #{hiredate}, #{sal}, #{comm}, #{deptno})")
    int insert(EmpDTO e);


    @Update("update emp set ename = #{ename}, hiredate = #{hiredate}, sal = #{sal} where empno = #{empno}")
    int update(EmpDTO e); // ENAME, HIREDATE, SAL만 업데이트 (JDBC 버전과 동일)

    @Delete("delete from emp where empno = #{empno}")
    int delete(Integer empno);
}