// EmpController.java
package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.EmpDTO;
import com.example.demo.service.EmpService;

@Controller
@RequestMapping("/emps")
public class EmpController {

   private final EmpService service;

    public EmpController(EmpService service) {
        this.service = service;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("emps", service.list());
        return "emp/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("emp", new EmpDTO());
        model.addAttribute("mode", "create");
        return "emp/add";
    }

    @PostMapping
    public String create(@ModelAttribute EmpDTO emp) {
        service.save(emp);
        return "redirect:/emps";
    }

    @GetMapping("/{empno}/edit")
    public String editForm(@PathVariable("empno") Integer empno, Model model) {
        var emp = service.get(empno).orElseThrow(() -> new IllegalArgumentException("Not found: " + empno));
        model.addAttribute("emp", emp);
        model.addAttribute("mode", "edit");
        return "emp/edit";
    }

    @PostMapping("/{empno}")
    public String update(@PathVariable("empno") Integer empno, @ModelAttribute EmpDTO emp) {
        emp.setEmpno(empno);
        service.save(emp);
        return "redirect:/emps";
    }

    @PostMapping("/{empno}/delete")
    public String delete(@PathVariable("empno") Integer empno) {
        service.delete(empno);
        return "redirect:/emps";
    }
}
