package com.exam.exception;

import com.exam.api.ApiResponse;
import com.exam.dto.TodoDTO;
import com.exam.service.TodoMyBatisService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class RestGlobalExceptionHandler {

    //필요한 빈 주입 가능.
    @Autowired
    TodoMyBatisService service;

    @ExceptionHandler(RecordNotFoundException.class)
    public ResponseEntity<ApiResponse<TodoDTO>> handleException(Exception e) {
        System.out.println("RestGlobalExceptionHandler>>>>>>>>>>>>>>>>>");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(ApiResponse.fail(e.getMessage(), null));
    }
    @ExceptionHandler(DuplicatedIdException.class)
    public ResponseEntity<ApiResponse<TodoDTO>> handleException2(Exception e) {
        System.out.println("RestGlobalExceptionHandler>>>>>>>>>>>>>>>>>");
        return ResponseEntity.status(HttpStatus.CONFLICT).
                body(ApiResponse.fail(e.getMessage(), null));
    }

    /** 400 - @Valid 본문 검증 실패 (DTO 필드 에러) */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Void>> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpServletRequest req) {
        System.out.println("@Valid >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + ex);
        // 가장 첫 번째 필드 오류 메시지 하나만 간결하게 반환 (ApiResponse 구조 변경 없이)
        String msg = ex.getBindingResult().getFieldErrors().stream()
                .findFirst()
                .map(err -> err.getField() + ": " + err.getDefaultMessage())
                .orElse("요청 본문이 올바르지 않습니다.");

        return ResponseEntity
                .badRequest()
                .body(ApiResponse.of(msg));
    }
    /** 400 - @Validated  검증 실패 */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiResponse<Void>> handleConstraintViolation(
            ConstraintViolationException ex, HttpServletRequest req) {
        System.out.println("@Validated  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + ex);
        String msg = ex.getConstraintViolations().stream()
                .findFirst()
                .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                .orElse("요청 파라미터가 올바르지 않습니다.");
        return ResponseEntity
                .badRequest()
                .body(ApiResponse.of(msg));
    }
}
