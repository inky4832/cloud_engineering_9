package com.exam.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.apache.ibatis.type.Alias;

@Alias("TodoDTO")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Builder
public class TodoDTO {

    int id;
    @NotBlank(message = "이름은 필수입니다.")
    @Size(max = 3, message = "이름은 3자 이하여야 합니다.")
    String name;
    String job;


}
