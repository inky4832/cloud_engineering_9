package com.app.mono;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.iam.IamClient;
import software.amazon.awssdk.services.iam.model.ListUsersRequest;
import software.amazon.awssdk.services.iam.model.ListUsersResponse;
import software.amazon.awssdk.services.iam.model.User;

@SpringBootApplication
public class AwsSdkApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsSdkApplication.class, args);

		// ==============================
		// 1. AWS Access Key / Secret Key 설정
		// ==============================
		String accessKey = "AKIA4AUDLX22TU64TTXC";
		String secretKey = "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";

		// AWS 기본 자격증명 객체 생성
		AwsBasicCredentials awsCredentials = AwsBasicCredentials.create(accessKey, secretKey);

		// ==============================
		// 2. IAM 클라이언트 생성
		// ==============================
		IamClient iamClient = IamClient.builder()
				.region(Region.AP_NORTHEAST_2) // 서울 리전
				.credentialsProvider(StaticCredentialsProvider.create(awsCredentials))
				.build();

		try {
			System.out.println("사용자 목록 출력");

			// ==============================
			// 3. IAM 사용자 목록 요청
			// ==============================
			ListUsersRequest request = ListUsersRequest.builder().build();

			ListUsersResponse response = iamClient.listUsers(request);

			// ==============================
			// 4. 결과 출력
			// ==============================
			for (User user : response.users()) {
				System.out.println("UserName = " + user.userName());
			}

		} catch (Exception e) {
			System.out.println("오류 발생");
			e.printStackTrace();
		} finally {
			iamClient.close();
		}
	}

}
