package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;


@RestController
public class EnvController {

    @Value("${app.message}")
    private String message;

    @Value("${app.upload-dir}")
    private String uploadDir;

    private final Environment environment;

    public EnvController(Environment environment) {
        this.environment = environment;
    }

    @GetMapping("/")
    public String home() {
        return "Spring Boot ENV Demo";
    }

    @GetMapping("/env")
    public Map<String, Object> env() {
        return Map.of(
                "message", message,
                "uploadDir", uploadDir,
                "activeProfiles", environment.getActiveProfiles()
        );
    }
}