package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/files")
public class FileController {

    private final Path uploadPath;

    public FileController(@Value("${app.upload-dir}") String uploadDir) throws Exception {
        this.uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
        Path path =  Files.createDirectories(this.uploadPath);
        System.out.println("Save Path:" + path.toString());
    }

    // 파일 업로드
    @PostMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile file) throws Exception {
        if (file.isEmpty()) {
            return "업로드할 파일이 없습니다.";
        }

        String fileName = file.getOriginalFilename();

        Path targetPath = uploadPath.resolve(fileName).normalize();

        file.transferTo(targetPath);

        return "업로드 성공: " + fileName;
    }

    // 파일 목록 조회
    @GetMapping
    public List<String> listFiles() throws Exception {
        return Files.list(uploadPath)
                .filter(Files::isRegularFile)
                .map(path -> path.getFileName().toString())
                .collect(Collectors.toList());
    }

    // 파일 다운로드
    @GetMapping("/{fileName}")
    public ResponseEntity<Resource> download(@PathVariable String fileName) throws MalformedURLException {
        Path filePath = uploadPath.resolve(fileName).normalize();

        Resource resource = new UrlResource(filePath.toUri());

        if (!resource.exists()) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }
}